public class Nomor1 {
    public static void main(String[] args) {

        // Cara 1
        int[] angka1 = new int[5];

        // Cara 2
        int[] angka2 = {10, 20, 30, 40, 50};

        // Cara 3
        int angka3[];
        angka3 = new int[]{1, 2, 3, 4, 5};

    }
}