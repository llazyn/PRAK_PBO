public class Nomor2 {
    public static void main(String[] args) {

        String[] mobil = {
            "Tesla", "Suzuki", "Civic", "Mazda", "BMW"
        };

        mobil[1] = "Toyota";

        System.out.println("Nilai indeks yang diubah: " + mobil[1]);
    }
}