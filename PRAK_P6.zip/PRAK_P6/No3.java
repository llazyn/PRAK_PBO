import java.util.Scanner;
import java.util.Arrays;

public class Nomor3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Masukkan jumlah elemen: ");
        int n = input.nextInt();

        int[] angka = new int[n];
        int total = 0;

        for (int i = 0; i < n; i++) {
            System.out.print("Angka ke-" + i + ": ");
            angka[i] = input.nextInt();
            total += angka[i];
        }

        int terbesar = angka[0];
        int terkecil = angka[0];

        for (int i = 0; i < n; i++) {
            if (angka[i] > terbesar) {
                terbesar = angka[i];
            }
            if (angka[i] < terkecil) {
                terkecil = angka[i];
            }
        }

        System.out.println("Nilai terbesar: " + terbesar);
        System.out.println("Nilai terkecil: " + terkecil);
        System.out.println("Jumlah: " + total);
        System.out.println("Rata-rata: " + (double) total / n);

        System.out.print("Masukkan NPM: ");
        int npm = input.nextInt();

        int jumlahIndeks = 0;
        if (npm % 2 == 0) {
            for (int i = 1; i < n; i += 2) {
                jumlahIndeks += angka[i];
            }
        } else {
            for (int i = 0; i < n; i += 2) {
                jumlahIndeks += angka[i];
            }
        }

        System.out.println("Jumlah sesuai indeks NPM: " + jumlahIndeks);
        if (jumlahIndeks % 2 == 0) {
            System.out.println("Hasil penjumlahan Genap");
        } else {
            System.out.println("Hasil penjumlahan Ganjil");
        }
        Arrays.sort(angka);
        System.out.println("Array setelah diurutkan: "
                + Arrays.toString(angka));

        input.close();
    }
}