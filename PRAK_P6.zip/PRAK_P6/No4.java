import java.util.Scanner;

public class Nomor4 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.print("Masukkan jumlah mahasiswa: ");
        int jumlah = s.nextInt();

        String[] nama = new String[jumlah];
        int[] nilai = new int[jumlah];
        String[] status = new String[jumlah];

        for (int i = 0; i < jumlah; i++) {
            System.out.println("\nMahasiswa ke-" + (i + 1));
            System.out.print("Nama: ");
            nama[i] = s.next();

            System.out.print("Nilai: ");
            nilai[i] = s.nextInt();

            if (nilai[i] > 50) {
                status[i] = "Lulus";
            } else {
                status[i] = "Tidak Lulus";
            }
        }

        System.out.println("\n========== Daftar Nilai Mahasiswa ==========");
        System.out.println("No\tNama\t\tNilai\tStatus");
        for (int i = 0; i < jumlah; i++) {
            System.out.println((i + 1) + "\t" + nama[i]
                    + "\t\t" + nilai[i] + "\t" + status[i]);
        }
        s.close();
    }
}