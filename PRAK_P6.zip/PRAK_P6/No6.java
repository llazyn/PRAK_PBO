import java.util.Scanner;

public class Nomor6 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.print("Masukkan jumlah bilangan: ");
        int jumlah = s.nextInt();

        double[] angka = new double[jumlah];
        double total = 0;
        for (int i = 0; i < jumlah; i++) {

            try {
                System.out.print("Masukkan bilangan ke-" + (i + 1) + ": ");
                angka[i] = Double.parseDouble(s.next());
                total += angka[i];
            } catch (NumberFormatException e) {
                System.out.println("Error! s harus berupa angka.");
                i--;
            }
        }
        double rataRata = total / jumlah;
        System.out.println("Jumlah: " + total);
        System.out.println("Nilai rata-rata: " + rataRata);
        s.close();
    }
}