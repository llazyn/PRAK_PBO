class ThreadBaru extends Thread {

    @Override
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println("Thread berjalan: " + i);
        }
    }
}

public class Nomor7 {
    public static void main(String[] args) {
        ThreadBaru thread = new ThreadBaru();
        thread.start();
        System.out.println("Thread utama berjalan");
    }
}