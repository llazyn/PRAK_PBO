import java.util.Scanner;

class ThreadAnak extends Thread {
    int nomor;
    ThreadAnak(int nomor) {
        this.nomor = nomor;
    }
    @Override
    public void run() {
        System.out.println("Thread ke-" + nomor + " sedang berjalan");
    }
}

public class Nomor8 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.print("Masukkan jumlah thread: ");
        int jumlah = s.nextInt();
        for (int i = 1; i <= jumlah; i++) {
            ThreadAnak thread = new ThreadAnak(i);
            thread.start();
        }
        s.close();
    }
}